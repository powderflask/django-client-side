""""
django-client-side.

Simple client-side dependency management
"""

__version__ = "0.2.0"
__author__ = 'powderflask'
default_app_config = 'client_side.apps.ClientSideConfig'